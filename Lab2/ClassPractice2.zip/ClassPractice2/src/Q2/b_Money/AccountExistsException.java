package Q2.b_Money;

public class AccountExistsException extends Exception {
	static final long serialVersionUID = 1L; 
}
