package EquivalanceClassPartition;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvSource;

class LeapYearTest {
	LeapYear ly;
	@BeforeEach
	void setUp() throws Exception {
	ly=new LeapYear();
	}
	

	@ParameterizedTest
	@CsvSource({"2016,true","2000,true","2017,false","1500,false"})
	void test(int year,boolean result) {
		assertEquals(result,ly.isLeapYear(year));
	}

}
